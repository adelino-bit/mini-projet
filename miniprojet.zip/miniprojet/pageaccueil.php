<?php
	// Initialiser la session
	session_start();
	// Vérifiez si l'utilisateur est connecté, sinon redirigez-le vers la page de connexion
	if(!isset($_SESSION["login"])){
		header("Location: connexion.php");
		exit(); 
	}
?>
<!DOCTYPE html>
<html>
	<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="css/connexion.css" />
	</head>
	<body>
		<div class="sucess">
		<h1>Bienvenue <?php echo $_SESSION['login']; ?> dans la page d’accueil de l’Admin!</h1> 
        <a href="logout.php">Déconnexion</a>
        
        <p>Aurélio Mendes</p>
		</ul>
		</div>
	</body>
</html>