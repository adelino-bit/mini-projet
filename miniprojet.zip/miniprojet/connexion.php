<?php

session_start();
$message='';

if (isset($_POST['submit']) || isset($_POST['login'])){
    $login = $_POST['login'];
    $motpasse = $_POST['password'];
    $_SESSION['login'] = $login;
    

    $file = 'user.json';
    $user = file_get_contents($file);
    $user = json_decode($user);


	
		
		// vérifier si l'utilisateur est un administrateur ou un utilisateur
		if (($login == $user[0]->login) && ($motpasse == $user[0]->password)  ) {
			header('location: pagejoueur.php');	  
		}else if (($login == $user[1]->login) && ($motpasse == $user[1]->password)){
			header('location: pageaccueil.php');
		}
	    else{
		$message = "Le nom d'utilisateur ou le mot de passe est incorrect.";
	    }
}



?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Page de connexion</title>
    <link rel="stylesheet" href="css/connexion.css">
</head>

<body>
    <div class="cadre">
        <div class="haut">
            <h2><strong> Le plaisir de jouer</strong></h2>
            <img src="../miniprojet/logo-QuizzSA.png" alt="Image du logo Quizz SA">
        </div>
        <div class="back">
            <div class="container">
                <div class="loginform">
                    <h3> Login Form &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;X

                    </h3>


                </div>
                <div class="form-input">
                    <form action="" method="post">
                        <input type="text" name="login" placeholder="Login" class="icon1" required/>
                        <br />

                        <input type="password" name="password" placeholder="Password" class="icon2" required/><br />
                        <input type="submit" name="submit" value="Connexion">
                        <a href="#"><b>S'inscrire pour jouer?</b></a>
                    
                
                        <?php if (! empty($message)) { ?>
                        <p class="erreurMessage"><?php echo $message; ?></p>
                        <?php } ?>
                    </form>
                </div>
            </div>

        </div>
        <div>
        </div>
</body>

</html>